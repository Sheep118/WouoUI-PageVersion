#ifndef __MAIN_H__
#define __MAIN_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "stdint.h"
#include <conio.h>
#include <graphics.h>
#include "WouoUI/WouoUI_user.h"


#ifdef __cplusplus
}
#endif

#endif