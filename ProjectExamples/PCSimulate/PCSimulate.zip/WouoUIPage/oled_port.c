#include "oled_port.h"

void OLED_SendBuff(uint8_t buff[8][128]) //将8*128字节的buff一次性全部发送的函数
{
    for (int y = 0; y < 8; ++y) {
        for (int x = 0; x < 128; ++x) {
            for (int bit = 0; bit < 8; ++bit) {
                uint8_t value = (buff[y][x] >> bit) & 1; // 获取相应位的值
                drawBigPixel(x, y*8+bit, value);
            }
        }
    }
}



