#ifndef SIMULAT_CONF_H
#define SIMULAT_CONF_H

#include <graphics.h>  /// 绘图库

#ifdef __cplusplus
extern "C" {
#endif

#include "WouoUIPage/oled_ui.h"  //获取oled屏幕大小的宏定义

#define PIXEL_SIZE  2       //每个像素点对应屏幕像素多少 2 = 2*2px
#define FORE_COLOR  LIGHTBLUE   //前景颜色
#define BACK_COLOR  WHITE   //背景颜色

#define SCREEN_WIDTH     PIXEL_SIZE*OLED_WIDTH  //仿真屏幕宽度
#define SCREEN_HEIGHT    PIXEL_SIZE*OLED_HEIGHT //仿真屏幕高度

#define KEY_UP          (key_A + 'A' - 'A')
#define KEY_DOWN        (key_A + 'D' - 'A')
#define KEY_CLICK       (key_A + 'S' - 'A')
#define KEY_RETURN      (key_A + 'W' - 'A')



#ifdef __cplusplus
}
#endif

#endif