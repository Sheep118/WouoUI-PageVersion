#ifndef __TEST_UI_H__
#define __TEST_UI_H__

#ifdef __cplusplus
extern "C" {
#endif

void TestUI_Init(void);
void TestUI_Proc(void);


#ifdef __cplusplus
}
#endif

#endif
