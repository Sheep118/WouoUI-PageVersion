#include <iostream>
#include "simulate_conf.h"
#ifdef USE_TEST_UI_EXAMPLE
#include "UITest/TestUI.h"
#else
#include "LittleClockUI/LittleClockUI.h"
#endif


int main()
{
    setrendermode(RENDER_MANUAL);	//设置为手动模式
    initgraph(SCREEN_WIDTH, SCREEN_HEIGHT); // 初始化图形窗口，因为是大像素,比实际窗口要大
	//颜色设置
	setbkcolor(BACK_COLOR);		//设置背景颜色
	setfillcolor(FORE_COLOR);	//设置填充颜色
#ifdef USE_TEST_UI_EXAMPLE
    TestUI_Init();
#else
    LittleClockUI_Init();
#endif
	while(is_run())//is_run() 判断窗口是否被关闭,窗口关闭则退出循环
    {
#ifdef USE_TEST_UI_EXAMPLE
        TestUI_Proc();
#else
        LittleClockUI_Proc();
#endif
        if(kbmsg()) //有键盘消息
        {
            key_msg msg = getkey();
            if ((msg.msg == key_msg_up)) 
            {
                switch (msg.key)
                {
                    case KEY_UP: OLED_MsgQueSend(msg_up); break;
                    case KEY_DOWN: OLED_MsgQueSend(msg_down); break;
                    case KEY_CLICK: OLED_MsgQueSend(msg_click); break;
                    case KEY_RETURN: OLED_MsgQueSend(msg_return); break;
                    default: break;
                }
            }   
        }
    }
	//绘图结束，关闭窗口
	closegraph();
	return 0;
}


// 画大像素点的函数（一个大像素由PIXEL_SIZExPIXEL_SIZE的小像素组成）
void drawBigPixel(int x, int y, uint8_t value) {
    COLORREF color = (value == 0 ? BACK_COLOR : FORE_COLOR); // 数组值为0，对应背景色；非0，对应前景色
    setfillcolor(color);	//设置填充颜色
    // 使用bar函数绘制一个大像素（PIXEL_SIZExPIXEL_SIZE块）
    int x0 = x * PIXEL_SIZE;
    int y0 = y * PIXEL_SIZE;
    bar(x0, y0, x0 + PIXEL_SIZE, y0 + PIXEL_SIZE); // bar函数的坐标是按照左上角和右下角来绘制矩形的
}