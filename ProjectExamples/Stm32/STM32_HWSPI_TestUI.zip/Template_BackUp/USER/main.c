/************************include************************************/
#include "stm32f10x.h"
#include "stdio.h"
#include "string.h"
#include "main.h"
#include "led.h"
#include "Shell.h"
#include "shell_port.h"
#include "log.h"
//#include "pack.h"
#include "TestUI.h"
#include "USART23.h"


/************************macro************************************/

//#undef  LOG_ENABLE
//#define LOG_ENABLE  0


/************************variants************************************/



/************************function declaration************************************/


int main(void)
{
    SysTick_Config(SystemCoreClock/1000);
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE); 
    //使能复用时钟，是为了能够禁用JTAG
    //禁用JTAG接口，只使能SWD,让PB4，PA15，PB3成为普通IO
    // User_Shell_Init(115200); //LetterShell我通常使用来打印log信息调试
    LED_Init();
    TestUI_Init();
    USART2_Init(115200); 

    while(1)
    {
        TestUI_Proc();
        if(USARTx_BUFF_AVAIBLE(USART2_RX_STA))
        {
            switch (USART2_RX_BUF[0]) //没有按键，使用串口代替
            {
                case 'a': OLED_MsgQueSend(msg_click); break;
                case 'b': OLED_MsgQueSend(msg_up); break;
                case 'c': OLED_MsgQueSend(msg_down); break;
                case 'd': OLED_MsgQueSend(msg_return); break;
                default: break;
            }
            USARTx_BUFF_RESET(&USART2_RX_STA);
        }

        if(task_flag[task_500ms_index]) //心跳灯
        {    
            LED_TOGGLE;
            task_flag[task_500ms_index] = 0;
        }
        
    }
}















