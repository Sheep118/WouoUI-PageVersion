#ifndef __KEY_H__
#define __KEY_H__

#include "air001xx_ll_gpio.h"
#include "air001xx_ll_bus.h"

enum
{
    Dkey_index = 0,
    Ckey_index,
    Ukey_index,
    //Rkey_index,
    KEY_NUM,
}; //按键下标的枚举类型

typedef enum //0 无按下; 1 短按松开; 2 长按保持; 3 长按松开
{
    key_none = 0,
    key_short,
    key_long_hold,
    key_long_release,
} KeyPressRes; //按键结果



#define DKEY_PORT   GPIOB
#define CKEY_PORT   GPIOB
#define UKEY_PORT   GPIOB
// #define RKEY_PORT   GPIOA
#define DKEY_PIN    LL_GPIO_PIN_3
#define CKEY_PIN    LL_GPIO_PIN_2
#define UKEY_PIN    LL_GPIO_PIN_1
// #define RKEY_PIN    LL_GPIO_PIN_0

#define KEY_SHORT_PRESS(x)  (x>3 && x<50)
#define KEY_LONG_HOLD(x)    (x>50)

typedef struct _key
{
    GPIO_TypeDef * key_port;
    uint16_t       key_pin;
    uint8_t        key_state:2; //0 wiat; 1 消抖; 2 计时 
    uint8_t        key_tick;
    KeyPressRes    key:2; //0 无按下; 1 短按松开; 2 长按保持; 3 长按松开
} Key;

extern Key gkey[KEY_NUM];

void Key_Init(void);
void Key_Reset(void);
void Key_Scan(void);

#endif
