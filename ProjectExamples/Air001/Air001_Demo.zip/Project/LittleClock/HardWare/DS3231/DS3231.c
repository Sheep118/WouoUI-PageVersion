#include "DS3231.h"

//DS3231 驱动部分
/**
* @brief : static uint8_t BCD2DEC(uint8_t bcd_val)
* @param : 16进制的BCD码
* @attention : 输入的BCD码长度只能为1字节
* @author : Sheep
* @date : 23/11/14
*/
static uint8_t BCD2DEC(uint8_t bcd_val)
{
    uint8_t i = 0;
    i = bcd_val&0x0f; //取出第四位的值 
    bcd_val >>= 4;  //将高四位移至第四位
    bcd_val &= 0x0f; //取出高四位
    bcd_val *= 10;  //高四位的值*10
    i += bcd_val;
    return i;
}

/**
* @brief : static uint8_t DEC2BCD(uint8_t dec_val)
* @param : 两位的十进制dec码
* @attention : 注意可输入的DEC值最大为99
* @author : Sheep
* @date : 23/11/14
*/
static uint8_t DEC2BCD(uint8_t dec_val)
{
    uint8_t i = 0,j = 0,k = 0;
    i = dec_val/10;
    j = dec_val%10;
    k = j+(i<<4);
    return k;
}


//供外界调用过的接口
/**
* @brief : uint16_t DS3231_SetHourMode(Calender* cal, bool hour_mode)
* @param : cal [in]日历结构体，hourmode[in] HOUR_MODE_24H/HOUR_MODE_12H
* @attention : None
* @author : Sheep
* @date : 23/11/14
*/
uint16_t DS3231_SetHourMode(Calender* cal, uint8_t hour_mode)
{
    uint16_t ret = 0 ;
    uint8_t hour_byte = 0;
    ret = I2C_ReadByte(DS3231_ADDRESS, DS3231_HOUR, &hour_byte); //读出原数值防止改变该时间值 
    if(hour_byte & 0x40 != hour_mode)
    {
        cal->hour_mode = hour_mode; //设置内部结构体
        hour_byte ^= (1<<6); //不同的话直接将这一位取反就可以了
        ret = I2C_WriteData(DS3231_ADDRESS, DS3231_HOUR, &hour_byte,1); //同步到DS3231中
    }
    return ret;
}

/**
* @brief : uint16_t DS3231_GetTime(Calender * cal)从ds3231中获取时间
* @param : cal [out]日历结构体
* @attention : None
* @author : Sheep
* @date : 23/11/14
*/
uint16_t DS3231_GetTime(Calender * cal)
{
    uint16_t ret = 0;
    ret = I2C_ReadByte(DS3231_ADDRESS,DS3231_SECOND,&(cal->sec));
    cal->sec = BCD2DEC(cal->sec);
    ret = I2C_ReadByte(DS3231_ADDRESS,DS3231_MINUTE,&(cal->min));
    cal->min = BCD2DEC(cal->min);
    ret = I2C_ReadByte(DS3231_ADDRESS,DS3231_HOUR,&(cal->hour));
    cal->hour_mode = (cal->hour&0x40);
    if(cal->hour_mode == HOUR_MODE_24H)
    {
        cal->hour &= 0x3f; //清除次高位，次高位表示12小时制还是24小时制
        cal->hour = BCD2DEC(cal->hour);
    }else if(cal->hour_mode == HOUR_MODE_12H)
    {
        cal->AM0_PM1 =  (cal->hour&0x20);
        cal->hour = BCD2DEC(cal->hour & 0x1f);
    }
    ret = I2C_ReadByte(DS3231_ADDRESS,DS3231_WEEK,&(cal->week));
    cal->week = BCD2DEC(cal->week);
    ret = I2C_ReadByte(DS3231_ADDRESS,DS3231_DAY,&(cal->day));
    cal->day = BCD2DEC(cal->day);
    ret = I2C_ReadByte(DS3231_ADDRESS,DS3231_MONTH,&(cal->month));
    cal->month &= 0x1f;
    cal->month = BCD2DEC(cal->month);
    ret = I2C_ReadByte(DS3231_ADDRESS,DS3231_YEAR,&(cal->year));
    cal->year = BCD2DEC(cal->year);
    return ret;
}

/**
* @brief : uint16_t DS3231_SetTime(Calender * cal)设置ds3231中的时间
* @param : cal [in]日历结构体
* @attention : None
* @author : Sheep
* @date : 23/11/14
*/
uint16_t DS3231_SetTime(Calender * cal)
{
    uint16_t ret = 0;
    uint8_t temp_byte = 0;
    temp_byte = DEC2BCD(cal->sec);
    ret = I2C_WriteData(DS3231_ADDRESS,DS3231_SECOND,&temp_byte,1);
    temp_byte = DEC2BCD(cal->min);
    ret = I2C_WriteData(DS3231_ADDRESS,DS3231_MINUTE,&temp_byte,1);
    
    temp_byte = DEC2BCD(cal->hour);
    if(cal->hour_mode == HOUR_MODE_12H)
    {
        temp_byte |= (1<<6);
        if(cal->AM0_PM1 == 1) //PM
            temp_byte |= (1<<5);
    }
    ret = I2C_WriteData(DS3231_ADDRESS,DS3231_HOUR,&temp_byte,1);

    temp_byte = DEC2BCD(cal->week);
    ret = I2C_WriteData(DS3231_ADDRESS,DS3231_WEEK,&temp_byte,1);
    temp_byte = DEC2BCD(cal->day);
    ret = I2C_WriteData(DS3231_ADDRESS,DS3231_DAY,&temp_byte,1);
    temp_byte = DEC2BCD(cal->month);
    ret = I2C_WriteData(DS3231_ADDRESS,DS3231_MONTH,&temp_byte,1);
    temp_byte = DEC2BCD(cal->year);
    ret = I2C_WriteData(DS3231_ADDRESS,DS3231_YEAR,&temp_byte,1);
    return ret;
}

/**
* @brief : uint16_t DS3231_SquareWaveOutput(SquareRate rate)
* @param : None
* @attention : 注意，实测，发现对DS3231SN该函数没有任何作用，不论如何设置，SQW输出频率均为1hz
* @author : Sheep
* @date : 23/10/26
*/
uint16_t DS3231_SquareWaveOutput(SquareRate rate)
{
    uint8_t temp = 0;
    uint16_t ret = 0;
    ret = I2C_ReadByte(DS3231_ADDRESS, DS3231_CONTROL, &temp);
    temp &= ~(1<<DS3231_INTCN_BIT); //SQW引脚做方波输出
    switch (rate)
    {
        case square_rate_1: temp &= ~(3<<DS3231_RS1_BIT); break;
        case square_rate_1024: 
                temp |=  (1<<DS3231_RS1_BIT);
                temp &= ~(1<<DS3231_RS2_BIT);
                break;
        case square_rate_4096: 
                temp &= ~(1<<DS3231_RS1_BIT);
                temp |= (1<<DS3231_RS2_BIT);
                break;
        case square_rate_8192: temp |= (3<<DS3231_RS1_BIT); break;
    default:
        break;
    }
    ret = I2C_WriteData(DS3231_ADDRESS, DS3231_CONTROL, &temp, 1); //写回控制寄存器
    return ret;
}

/**
* @brief : uint16_t DS3231_GetTemp(float * temperature)获取ds3231b内部传感器的温度
* @param : temperature [out]获取温度传感器的指针
* @attention : 注意，该函数没有实际测试过
* @author : Sheep
* @date : 23/11/14
*/
uint16_t DS3231_GetTemp(float * temperature)
{
    uint8_t temp = 0;
    uint16_t ret = 0;
    ret = I2C_ReadByte(DS3231_ADDRESS, DS3231_STATUS, &temp);
    if(temp & 1<<(DS3231_BSY_BIT))return 1; //正在进行温度转换
    else
    {
        ret = I2C_ReadByte(DS3231_ADDRESS, DS3231_TEMPERATUREH, &temp); //整数部分
        *temperature = (float)temp;
        ret = I2C_ReadByte(DS3231_ADDRESS, DS3231_TEMPERATUREL, &temp); //小数部分
        if(temp &0x80) *temperature += (float)0.5;
        if(temp &0x40) *temperature += (float)0.25;
    }
    return ret;
}


/**
* @brief : uint16_t DS3231_SetAlarm(Alarm * al)
* @param : al [in]闹钟结构体
* @attention : 注意闹钟的模式
* @author : Sheep
* @date : 23/11/14
*/
uint16_t DS3231_SetAlarm(Alarm * al)
{   
    uint16_t ret = 0;
    uint8_t temp_send_array[4] = {DEC2BCD(al->sec),DEC2BCD(al->min),DEC2BCD(al->hour),DEC2BCD(al->day)};
    switch (al->mode)
    {
        case repeat_month_mode: //每月重复的话(0000,0)
            temp_send_array[1] &= ~(1<<7);
            temp_send_array[2] &= ~(1<<7);
            temp_send_array[3] &= ~(1<<7);
            temp_send_array[3] &= ~(1<<6);
            break;
        case repeat_week_mode: //每周重复的话(0000,1)
            temp_send_array[1] &= ~(1<<7);
            temp_send_array[2] &= ~(1<<7);
            temp_send_array[3] &= ~(1<<7);
            temp_send_array[3] |= (1<<6);
            break;
        case repeat_min_mode: //每分钟都重复的话(0111,0)
            temp_send_array[1] |= (1<<7);
            temp_send_array[2] |= (1<<7);
            temp_send_array[3] |= (1<<7);
            break;
        case repeat_hour_mode: //每小时都重复的话()
            temp_send_array[1] &= ~(1<<7);
            temp_send_array[2] |= (1<<7);
            temp_send_array[3] |= (1<<7);
            break;
        case repeat_day_mode : //每日重复的话
            temp_send_array[1] &= ~(1<<7);
            temp_send_array[2] &= ~(1<<7);
            temp_send_array[3] |= (1<<7);
            break;
    default:
        break;
    }
    if(al->id == 0) //闹钟1的话
        ret = I2C_WriteData(DS3231_ADDRESS, DS3231_ALARM1SECOND, temp_send_array, 4);
    else if(al->id == 1) //闹钟2的话
        ret = I2C_WriteData(DS3231_ADDRESS, DS3231_ALARM2MINUTE, &(temp_send_array[1]),3);
    return ret;
}



/**
* @brief : uint16_t DS3231_StartAlarm(Alarm *al)开启一个设置好的闹钟 /uint16_t DS3231_StopAlarm(Alarm *al) 关闭一个闹钟
* @param : al [in]闹钟结构体
* @attention : None
* @author : Sheep
* @date : 23/11/14
*/
uint16_t DS3231_StartAlarm(Alarm *al)
{
    uint8_t temp = 0;
    uint16_t ret = I2C_ReadByte(DS3231_ADDRESS, DS3231_CONTROL, &temp);
    temp |= (1<<DS3231_INTCN_BIT); //SQW引脚做中断输出
    temp |= (1<<DS3231_BBSQW_BIT); //SQW脚在电池供电时也输出
    if(al->id == 0)temp |= (1<<DS3231_A1IE_BIT);
    else if(al->id == 1)temp |= (1<<DS3231_A2IE_BIT);
    ret = I2C_WriteData(DS3231_ADDRESS, DS3231_CONTROL, &temp, 1); //写回控制寄存器
    return ret;
}
uint16_t DS3231_StopAlarm(Alarm *al)
{
    uint8_t temp = 0;
    uint16_t ret = I2C_ReadByte(DS3231_ADDRESS, DS3231_CONTROL, &temp);
    if(al->id == 0)temp &= ~(1<<DS3231_A1IE_BIT);
    else if(al->id == 1)temp &= ~(1<<DS3231_A2IE_BIT);
    ret = I2C_WriteData(DS3231_ADDRESS, DS3231_CONTROL, &temp, 1); //写回控制寄存器
    return ret;
}

/**
* @brief : uint16_t DS3231_ClearAlarm(Alarm * al)
* @param : al [in]闹钟结构体
* @attention : 注意，该函数用于在中断(或者主循环也可以)清除一个闹钟提醒的响应，如果没有清除该响应，ds3231的INT引脚会一直保持闹铃状态
* @author : Sheep
* @date : 23/11/14
*/
uint16_t DS3231_ClearAlarm(Alarm * al)
{
    uint8_t temp = 0;
    uint16_t ret = 0;
    ret = I2C_ReadByte(DS3231_ADDRESS, DS3231_STATUS, &temp);
    if(al->id == 0) temp &= ~(1<<DS3231_A1F_BIT);
    else if(al->id == 1) temp &= ~(1<<DS3231_A2F_BIT);
    ret = I2C_WriteData(DS3231_ADDRESS, DS3231_STATUS, &temp, 1); //写回控制寄存器
    return ret;
}


/**
* @brief : uint16_t DS3231_ClearAnyAlarm(uint8_t *al_id)
* @param : al_id [in]uint8_t 获得当前响铃闹钟的id
* @attention : 注意，该函数用于在中断(或者主循环也可以)清除一个闹钟提醒的响应，如果没有清除该响应，ds3231的INT引脚会一直保持闹铃状态
* @author : Sheep
* @date : 23/11/14
*/
uint16_t DS3231_ClearAnyAlarm(uint8_t *al_id)
{
    uint8_t temp = 0;
    uint16_t ret = 0;
    ret = I2C_ReadByte(DS3231_ADDRESS, DS3231_STATUS, &temp);
    if(temp & 0x01) {temp &= ~(1<<DS3231_A1F_BIT); *al_id = 1;}
    if(temp & 0x02) {temp &= ~(1<<DS3231_A2F_BIT); *al_id = 2;} //如果有哪个闹钟响了，就清除哪个
    ret = I2C_WriteData(DS3231_ADDRESS, DS3231_STATUS, &temp, 1); //写回控制寄存器
    return ret;
}

//ds3231里没有获取闹钟的函数，补一个(因为暂时使用的闹钟都是每日重复模式，所以没有判断模式)
uint16_t DS3231_GetAlarmTime(Alarm *al, uint8_t* enabled)
{
    uint8_t temp_receive_array[3] = {0};
    uint8_t temp_buff; 
    uint16_t ret = 0;
    if(al->id == 0) //闹钟1的话
    {
        for(uint8_t i = 0; i < 3; i++)
            ret = I2C_ReadByte(DS3231_ADDRESS,DS3231_ALARM1SECOND+i, &(temp_receive_array[i]));
        al->sec = BCD2DEC(temp_receive_array[0]&0x7F);
        al->min = BCD2DEC(temp_receive_array[1]&0x7F);
        al->hour = BCD2DEC(temp_receive_array[2]&0x3F);
        ret = I2C_ReadByte(DS3231_ADDRESS, DS3231_CONTROL, &temp_buff);
        *enabled = (temp_buff&0x01); 
    }
    else if(al->id == 1) //闹钟2的话
    {
        for(uint8_t i = 0; i < 2; i++)
            ret = I2C_ReadByte(DS3231_ADDRESS,DS3231_ALARM2MINUTE+i, &(temp_receive_array[i]));
        al->min = BCD2DEC(temp_receive_array[0]&0x7F);
        al->hour = BCD2DEC(temp_receive_array[1]&0x3F);
        I2C_ReadByte(DS3231_ADDRESS, DS3231_CONTROL, &temp_buff);
        *enabled = (temp_buff&0x02); 
    }
    return ret;
}

