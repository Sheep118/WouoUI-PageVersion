#ifndef __DS3231_H__
#define __DS3231_H__

#include "stdint.h"
#include "stdio.h"
# include "DS3231_port.h"



//DS3231驱动结构体
typedef struct 
{
    uint8_t hour_mode:1;
    uint8_t AM0_PM1:1;
    uint8_t hour;
    uint8_t min;
    uint8_t sec;
    uint8_t day;
    uint8_t week;
    uint8_t month;
    uint8_t year;    
    uint16_t temperature;
} Calender;

typedef enum
{
    repeat_month_mode, //每个月重复一次(日时分秒匹配)
    repeat_week_mode, //每个周重复一次(星期时分秒匹配)
    repeat_day_mode, //每天重复一次(时分秒匹配)
    repeat_hour_mode, //每小时重复一次(时分匹配)
    repeat_min_mode, //每分钟重复一次(Alarm1是匹配到秒，Alarm2是匹配到00秒)
} AlarmMode;


typedef struct 
{
    uint8_t id:1; //id 0/1 <==>Alarm1 和Alram2
    uint8_t sec;
    uint8_t min;
    uint8_t hour;
    uint8_t day; //day or date
    AlarmMode mode;//运行模式
} Alarm; //闹钟默认24小时制,有AMPM不过没必要

typedef enum
{
    square_rate_1,      //1hz
    square_rate_1024,   //1024hz
    square_rate_4096,   //4096hz
    square_rate_8192,   //8192hz
} SquareRate;

#define HOUR_MODE_24H  0
#define HOUR_MODE_12H  1


// DS3231 地址定义 
#define 	DS3231_ADDRESS   	     (0x68<<1) //8bit地址
//DS3231 寄存器表
#define		DS3231_SECOND            0x00    //秒
#define 	DS3231_MINUTE      		 0x01    //分
#define 	DS3231_HOUR        		 0x02    //时
#define 	DS3231_WEEK         	 0x03    //星期
#define 	DS3231_DAY          	 0x04    //日
#define 	DS3231_MONTH             0x05    //月
#define     DS3231_YEAR        	     0x06    //年 	 
/* 闹铃1 */          	
#define     DS3231_ALARM1SECOND      0x07    //秒
#define 	DS3231_ALARM1MINUTE      0x08    //分
#define     DS3231_ALARM1HOUR        0x09    //时
#define 	DS3231_ALARM1WEEK  		 0x0A    //星期/日
/* 闹铃2 */
#define 	DS3231_ALARM2MINUTE 	 0x0b    //分
#define 	DS3231_ALARM2HOUR        0x0c    //时
#define 	DS3231_ALARM2WEEK        0x0d    //星期/日
 
#define 	DS3231_CONTROL           0x0e    //控制寄存器
    //控制寄存器的位定义
    #define DS3231_EOSC_BIT             7    //是否在电池供电时开启振荡器
    #define DS3231_BBSQW_BIT            6    //是否在电池供电时使能SWQ输出
    #define DS3231_CONV_BIT             5    //温度矫正寄存器
    #define DS3231_RS2_BIT              4    //速率设置寄存器2
    #define DS3231_RS1_BIT              3    //速率设置寄存器1
    #define DS3231_INTCN_BIT            2    //中断输出控制
    #define DS3231_A2IE_BIT             1    //Alarm2中断使能
    #define DS3231_A1IE_BIT             0    //Alarm1中断使能
#define 	DS3231_STATUS            0x0f    //状态寄存器
    //状态寄存器的位定义
    #define 	DS3231_OSF_BIT           7       //振荡器停止标志
    #define 	DS3231_BSY_BIT           2       //忙
    #define 	DS3231_A2F_BIT           1       //Alarm 2
    #define 	DS3231_A1F_BIT           0       //Alarm 1
#define 	DS3231_XTAL         	 0x10    //晶体老化寄存器
#define 	DS3231_TEMPERATUREH 	 0x11    //温度寄存器高字节(8位)
#define 	DS3231_TEMPERATUREL 	 0x12    //温度寄存器低字节(高2位) 																				


void DS3231_IICInit(void);
// void DS3231_IICEnable(void);
// void DS3231_IICDisable(void);
uint16_t DS3231_SetHourMode(Calender* cal, uint8_t hour_mode);
uint16_t DS3231_GetTime(Calender * cal);
uint16_t DS3231_SetTime(Calender * cal);

uint16_t DS3231_SetAlarm(Alarm * al);
uint16_t DS3231_StartAlarm(Alarm *al);
uint16_t DS3231_StopAlarm(Alarm *al);
uint16_t DS3231_SquareWaveOutput(SquareRate rate);
uint16_t DS3231_GetTemp(float * temperature);
uint16_t DS3231_ClearAlarm(Alarm * al);
uint16_t DS3231_ClearAnyAlarm(uint8_t *al_id);
uint16_t DS3231_GetAlarmTime(Alarm *al, uint8_t* enabled);
//void DS3231_AlarmIntInit(uint32_t pin,nrfx_gpiote_evt_handler_t callback);
#endif
