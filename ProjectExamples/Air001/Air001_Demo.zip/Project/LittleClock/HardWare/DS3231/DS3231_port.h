#ifndef __DS3231_PORT_H__
#define __DS3231_PORT_H__


#include "air001xx_ll_gpio.h"
#include "air001xx_ll_bus.h"
#include "air001xx_ll_i2c.h"
#include "air001xx_ll_exti.h"
#include "stdio.h"
//DS3231的TWI驱动配置
#define DS3231_SCL_PIN       LL_GPIO_PIN_1
#define DS3231_SDA_PIN       LL_GPIO_PIN_0
#define DS3231_SCL_PORT       GPIOF
#define DS3231_SDA_PORT       GPIOF

#define DS3231_INT_PIN       LL_GPIO_PIN_0
#define DS3231_INT_PORT      GPIOA


#define DS3231_TIMEOUT       60000
#define DS3231_LOG          printf

void DS3231_IICInit(void);
uint16_t I2C_WriteData(uint8_t slaveAddr, uint8_t regAddr, uint8_t *pData, uint16_t dataLen);
uint16_t I2C_ReadByte(uint8_t slaveAddr, uint8_t regAddr, uint8_t* Data);
void DS3231_IntInit(void);

// void DS3231_IICEnable(void)
// {
//     nrf_drv_twi_enable(&s_ds3231_twi);
// }

// void DS3231_IICDisable(void)
// {
//     nrf_drv_twi_disable(&s_ds3231_twi);
// }

#endif

