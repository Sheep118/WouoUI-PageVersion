#ifndef __LED_H__
#define __LED_H__

#include "air001xx_ll_gpio.h"
#include "air001xx_ll_bus.h"


#define LED_PORT GPIOB
#define LED_PIN  LL_GPIO_PIN_0


void LED_Init(void);
void SystemClock_Init(void);
__STATIC_INLINE void LED_TOGGLE(void)
{
  WRITE_REG(LED_PORT->ODR, READ_REG(LED_PORT->ODR) ^ LED_PIN);
}

__STATIC_INLINE void LED_OFF(void)
{
  WRITE_REG(LED_PORT->BSRR, READ_REG(LED_PORT->BSRR) | LED_PIN);
}

__STATIC_INLINE void LED_ON(void)
{
  WRITE_REG(LED_PORT->BRR, READ_REG(LED_PORT->BRR) | LED_PIN);
}

#endif
