#ifndef __SHELL_PORT__
#define __SHELL_PORT__

#include "air001xx_hal.h"
#include "shell.h"

#define SHELL_USART USART1
#define SHELL_USART_IRQ USART1_IRQn


void User_Shell_Init(uint32_t baudrate);
extern Shell shell;
#define my_shell_print(fmt,...) shellPrint(&shell,fmt,##__VA_ARGS__)

#endif
