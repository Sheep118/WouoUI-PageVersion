#ifndef __BATADC_H__
#define __BATADC_H__

#include "air001xx_ll_bus.h"
#include "air001xx_ll_adc.h"
#include "air001xx_ll_gpio.h"
#include "air001xx_ll_utils.h"
#include "System.h"

void BATADC_Init(void);
uint16_t BATADC_Read(void);


#endif

