#define DEBUG_ENABLE 1
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "System.h"
#include "key.h"
#if DEBUG_ENABLE
#include "LED.h"
#include "debug_uart.h"
#endif
#include "DS3231.h"
#include "LittleClockUI.h"
#include "BATADC.h"

Calender cal = 
{
    .hour_mode = HOUR_MODE_24H,
    .year = 24,
    .month = 2,
    .day = 12,
    .week = 1,
    .hour = 21,
    .min = 44,
    .sec = 55,
};
Alarm alarm = {.mode = repeat_day_mode}; //每天重复一次的闹钟
uint8_t alarm_ring_id = 0; 



void DS3231_GetAlarm_SetFlag(uint8_t al_num)
{
    uint8_t alatm_sta = 0;
    uint8_t msk = 0;
    DigitalPage * temp_dp = NULL;
    if(al_num == 1){alarm.id = 0; temp_dp = &alarm1_page; msk = ALARM1_ENABLE_MSK;}//查询闹钟1的信息
    else if(al_num == 2){alarm.id = 1;temp_dp = &alarm2_page; alarm.sec = 0; msk = ALARM2_ENABLE_MSK;}//查询闹钟2的信息
    DS3231_GetAlarmTime(&alarm, &alatm_sta);
    OLED_DigitalPage_UpdateDigitalNumAnimation(temp_dp ,alarm.hour, alarm.min, alarm.sec, Digital_Direct_Increase);
    if(alatm_sta != 0) SET_FLAG(update_flag, msk);
    else CLEAR_FLAG(update_flag, msk);
}

//更改step为0是数值弹窗进入时，会调用一次回调函数，未测试


/**
  * @brief  应用程序入口函数.
  * @retval int
  */
int main(void)
{   
    SystemClock_Init();
    Key_Init();
#if DEBUG_ENABLE
    LED_Init();
		DebugUART_Init(115200);
#endif
    LittleClockUI_Init();
    DS3231_IntInit(); //闹钟中断
    DS3231_IICInit();
    LL_mDelay(100);
    DS3231_GetTime(&cal);
    OLED_DigitalPage_UpdateDigitalNumAnimation(&clock_page,cal.hour, cal.min, cal.sec, Digital_Direct_Increase);
    OLED_DigitalPage_UpdateDigitalNumAnimation(&calendar_page,cal.year, cal.month, cal.day, Digital_Direct_Increase);
    OLED_DigitalPage_UpdateLabelAnimation(&calendar_page, cal.week -1, Digital_Direct_Increase);
    OLED_DigitalPage_UpdateLabelAnimation(&clock_page, cal.week -1, Digital_Direct_Increase);
    
    DS3231_GetAlarm_SetFlag(1);
    DS3231_GetAlarm_SetFlag(2);
    BATADC_Init();

    uint16_t count = 0;
    
    while(1)
    {
      LittleClockUI_Proc();
      if(OLED_UIGetCurrentPageID() == ring_page.page.page_id) //在ring页面按下任意键
      {
          if((gkey[Dkey_index].key != key_none) || (gkey[Ckey_index].key != key_none) || (gkey[Ukey_index].key != key_none))
          {
              if(FLAG_IS_SET(update_flag,ALARM1_RING_MSK) )
                {OLED_UIChangeCurrentPage(&alarm1_page);CLEAR_FLAG(update_flag,ALARM1_RING_MSK);}
              if(FLAG_IS_SET(update_flag,ALARM2_RING_MSK))
                {OLED_UIChangeCurrentPage(&alarm2_page);CLEAR_FLAG(update_flag,ALARM2_RING_MSK);}
          }
      } //因此在ring页面不会给消息队列发送消息
      else {
          if(gkey[Ukey_index].key == key_short || gkey[Ukey_index].key == key_long_hold)
              OLED_MsgQueSend(msg_up);
          if(gkey[Ckey_index].key == key_short)
              OLED_MsgQueSend(msg_click);
          else if(gkey[Ckey_index].key == key_long_release)
              OLED_MsgQueSend(msg_return);
          if(gkey[Dkey_index].key == key_short || gkey[Dkey_index].key == key_long_hold)
              OLED_MsgQueSend(msg_down);
      }
      Key_Reset();
      if(FLAG_IS_SET(update_flag,TIME_UPDATE_MSK))
      {
          cal.hour = clock_page.option_array[Digital_Pos_IndexLeft].val;
          cal.min = clock_page.option_array[Digital_Pos_IndexMid].val;
          cal.sec = clock_page.option_array[Digital_Pos_IndexRight].val;
          cal.week = clock_page.select_label_index+1;
          DS3231_SetTime(&cal);
          CLEAR_FLAG(update_flag,TIME_UPDATE_MSK);
      }
      if(FLAG_IS_SET(update_flag, DATE_UPDATE_MSK))
      {
          cal.year = calendar_page.option_array[Digital_Pos_IndexLeft].val;
          cal.month = calendar_page.option_array[Digital_Pos_IndexMid].val;
          cal.day = calendar_page.option_array[Digital_Pos_IndexRight].val;
          cal.week = calendar_page.select_label_index+1;
          DS3231_SetTime(&cal);
          CLEAR_FLAG(update_flag,DATE_UPDATE_MSK);
      }
      if(FLAG_IS_SET(update_flag, ALARM1_UPDATE_MSK))
      {
          alarm.id = 0; alarm.day = cal.day;  
          alarm.hour = alarm1_page.option_array[Digital_Pos_IndexLeft].val;
          alarm.min = alarm1_page.option_array[Digital_Pos_IndexMid].val;
          alarm.sec = alarm1_page.option_array[Digital_Pos_IndexRight].val;
          DS3231_SetAlarm(&alarm);
          LL_mDelay(100);//因为air001硬件iic的问题，需要加上延时
          CLEAR_FLAG(update_flag,ALARM1_UPDATE_MSK);
          if(FLAG_IS_SET(update_flag, ALARM1_ENABLE_MSK)) //使能、失能闹钟后必然会过编辑完成(Update)
              DS3231_StartAlarm(&alarm);
          else 
              DS3231_StopAlarm(&alarm); 
      }
      if(FLAG_IS_SET(update_flag, ALARM2_UPDATE_MSK))
      {
          alarm.id = 1; alarm.day = cal.day;  
          alarm.hour = alarm2_page.option_array[Digital_Pos_IndexLeft].val;
          alarm.min = alarm2_page.option_array[Digital_Pos_IndexMid].val;
          DS3231_SetAlarm(&alarm);
          LL_mDelay(100); //因为air001硬件iic的问题，需要加上延时
          CLEAR_FLAG(update_flag,ALARM2_UPDATE_MSK);
          if(FLAG_IS_SET(update_flag, ALARM2_ENABLE_MSK)) //使能、失能闹钟后必然会过编辑完成(Update)
              DS3231_StartAlarm(&alarm);
          else 
              DS3231_StopAlarm(&alarm); 
      }
      if(alarm_ring_id == 1)
      {
          SET_FLAG(update_flag, ALARM1_RING_MSK);
          OLED_UIChangeCurrentPage(&ring_page); 
          alarm_ring_id = 0;
      }
      else if(alarm_ring_id == 2)
      {
          SET_FLAG(update_flag, ALARM2_RING_MSK);
          OLED_UIChangeCurrentPage(&ring_page); 
          alarm_ring_id = 0;
      }

      if(task_flag[key_task_index]) //10ms一次
      {
        Key_Scan();
        task_flag[key_task_index] = 0;
      }
      count++;
      if(task_flag[debug_uart_index])//1s一次
      {
#if DEBUG_ENABLE
					// printf("fps: %d\r\n",count);
          //printf("adc= %d\r\n",BATADC_Read());
          LED_TOGGLE();
#endif
          if(clock_page.mod == Digital_Mode_Observe && (!FLAG_IS_SET(update_flag,TIME_UPDATE_MSK)))
          { //处于观察模式，且没有设置时间时才会更新时间
              DS3231_GetTime(&cal);
              OLED_DigitalPage_UpdateDigitalNumAnimation(&clock_page,cal.hour, cal.min, cal.sec, Digital_Direct_Increase);
              if(cal.hour == 0 && cal.min == 0 && cal.sec == 1) //每天第一秒刷新一次日程
              {
                OLED_DigitalPage_UpdateDigitalNumAnimation(&calendar_page,cal.year, cal.month, cal.day, Digital_Direct_Increase);
                OLED_DigitalPage_UpdateLabelAnimation(&calendar_page, cal.week -1, Digital_Direct_Increase);
                OLED_DigitalPage_UpdateLabelAnimation(&clock_page, cal.week -1, Digital_Direct_Increase);
              }
          }
          fps = count;
          count = 0;
          task_flag[debug_uart_index] = 0;
      }
    }
}


void EXTI0_1_IRQHandler(void)
{
    if(LL_EXTI_IsActiveFlag(LL_EXTI_LINE_0))
    {
        DS3231_ClearAnyAlarm(&alarm_ring_id);
        LL_EXTI_ClearFlag(LL_EXTI_LINE_0);
    }
}




/**
  * @brief  错误执行函数
  * @param  无
  * @retval 无
  */
void Error_Handler(void)
{
  /* 无限循环 */
  while (1)
  {
  }
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  输出产生断言错误的源文件名及行号
  * @param  file：源文件名指针
  * @param  line：发生断言错误的行号
  * @retval 无
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* 用户可以根据需要添加自己的打印信息,
     例如: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* 无限循环 */
  while (1)
  {
  }
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT AirM2M *****END OF FILE******************/
