#include "WouoUI_win.h"
#include "WouoUI.h"

/**
 * @brief OLED_WinFSM函数用于处理窗口的状态机
 *
 * @param w 指向窗口结构体的指针
 * @param bg 页面地址
 * @param select_item 指向选项结构体的指针
 * @param time 状态机轮询间隔时间
 */
void OLED_WinFSM(Win *w, PageAddr bg, Option *select_item, uint16_t time) {
    switch (w->state) {
    case 1:
        w->animInit(bg, time);
        w->state = 2;
        break; // 初始化只用在弹窗最开始时做—次弹窗参数初始化
    case 2:
        w->show(select_item, time);
        w->react(bg, select_item, time);
        break; // 弹窗动画和交互
    default:
        break;
    }
}

//------------弹窗背景虚化
void OLED_WinBlurAnimInit(void) {
    p_cur_ui->pageBlur.state = 0;
    p_cur_ui->pageBlur.timer = 0;
}

void OLED_WinBlurAnim(uint16_t time) {
    if (p_cur_ui->upara->win_blur) { // 如果要背景虚化的话
        p_cur_ui->pageBlur.timer += time;
        if (p_cur_ui->pageBlur.timer >= p_cur_ui->upara->ani_param[FADE_ANI] && p_cur_ui->pageBlur.state < 2) {
            p_cur_ui->pageBlur.state++;
            p_cur_ui->pageBlur.timer = 0;
        }
        OLED_SetPointColor(0);
        switch (p_cur_ui->pageBlur.state) {
        case 0:
            OLED_AllBlur(BLUR_1_4);
            break;
        case 1:
            OLED_AllBlur(BLUR_2_4);
            break;
        case 2:
            OLED_AllBlur(BLUR_3_4);
            break;
        default:
            break;
        }
        OLED_SetPointColor(1);
    }
}

//------------数值弹窗相关函数
void OLED_SlideValWinAnimInit(PageAddr bg, uint16_t time) {
    UNUSED_PARAMETER(bg);
    p_cur_ui->slideValWin.win.y = WIN_Y_TGT;
    p_cur_ui->slideValWin.win.y_tgt = p_cur_ui->slideValWin.win.u;
    OLED_WinBlurAnimInit();
}

void OLED_SlideValWinShow(Option *win, uint16_t time) {
    OLED_WinBlurAnim(time);

    OLED_Animation(&p_cur_ui->slideValWin.win.y, &p_cur_ui->slideValWin.win.y_tgt, p_cur_ui->upara->ani_param[WIN_ANI], time);

    OLED_SetPointColor(0);
    OLED_WinDrawRBox(&w_all, p_cur_ui->slideValWin.win.l, (int16_t)p_cur_ui->slideValWin.win.y,
                     SLI_VAL_WIN_W, SLI_VAL_WIN_H, 2); // 弹窗背景黑边
    OLED_SetPointColor(1);
    OLED_WinDrawRBoxEmpty(&w_all, p_cur_ui->slideValWin.win.l, (int16_t)p_cur_ui->slideValWin.win.y,
                          SLI_VAL_WIN_W, SLI_VAL_WIN_H, 2); // 弹窗外框

    OLED_WinDrawRBoxEmpty(&w_all, p_cur_ui->slideValWin.slideValWidget.l, (int16_t)p_cur_ui->slideValWin.win.y + SLI_VAL_WIN_BAR_Y_OFS,
                          SLI_VAL_WIN_BAR_W, SLI_VAL_WIN_BAR_H, SLI_VAL_WIN_BAR_R); // 进度条外框

    OLED_WinDrawStr(&w_all, p_cur_ui->slideValWin.win.l + 5,
                    (int16_t)p_cur_ui->slideValWin.win.y + 4, WIN_FONT, (uint8_t *)&(win->text[2])); // 提示文本跳过“~ ”
    OLED_WinDrawStr(&w_all, p_cur_ui->slideValWin.win.r - 5 - OLED_GetStrWidth(ui_itoa(win->val), WIN_FONT),
                    (int16_t)p_cur_ui->slideValWin.win.y + 4, WIN_FONT, (uint8_t *)(ui_itoa(win->val))); // 当前数值
    OLED_WinDrawStr(&w_all, p_cur_ui->slideValWin.slideValWidget.l - 2 - OLED_GetStrWidth(ui_itoa(win->item_min), SLI_VAL_WIN_FONT),
                    (int16_t)p_cur_ui->slideValWin.win.y + 20, SLI_VAL_WIN_FONT, (uint8_t *)(ui_itoa(win->item_min))); // 最小值
    OLED_WinDrawStr(&w_all, p_cur_ui->slideValWin.slideValWidget.r + 2,
                    (int16_t)p_cur_ui->slideValWin.win.y + 20, SLI_VAL_WIN_FONT, (uint8_t *)(ui_itoa(win->item_max))); // 最大值

    // indicator
    p_cur_ui->indicator.x_tgt = p_cur_ui->slideValWin.slideValWidget.l + 2;
    p_cur_ui->indicator.y_tgt = p_cur_ui->slideValWin.slideValWidget.u + 2;
    p_cur_ui->indicator.w_tgt = (float)(win->val - win->item_min) / (float)(win->item_max - win->item_min) * (SLI_VAL_WIN_BAR_W - 4);
    p_cur_ui->indicator.h_tgt = SLI_VAL_WIN_BAR_H - 4;
}

void OLED_SlideValWinReact(PageAddr bg, Option *select_win, uint16_t time) {
    if (p_cur_ui->slideValWin.win.y == p_cur_ui->slideValWin.win.y_tgt && p_cur_ui->slideValWin.win.y != WIN_Y_TGT) // 弹窗进场动画结束时
    {
        InputMsg msg = OLED_MsgQueRead();
        switch (msg) {
        case msg_add:
            if (select_win->val < select_win->item_max)
                select_win->val += select_win->step;
            break;
        case msg_sub:
            if (select_win->val > select_win->item_min)
                select_win->val -= select_win->step;
            break;
        case msg_click: // 点击确认也会退出弹窗，不过，点击确认是会触发一次回调，点击返回则不会
        case msg_return:
            p_cur_ui->slideValWin.win.y_tgt = WIN_Y_TGT; // 弹窗退场
            p_cur_ui->slideValWin.win.state = 0;         // 状态标志，退出弹窗
            break;
        default:
            break;
        }
        if (msg != msg_none && msg != msg_return) // 只有弹窗内有动作，就会实时触发回调
        {
            Page *p = (Page *)bg;
            if (p->cb != NULL)
                p->cb(p, select_win);
        }
    }
}

//------------信息弹窗相关函数
void OLED_InfoWinAnimInit(PageAddr bg, uint16_t time) {
    UNUSED_PARAMETER(bg);
    p_cur_ui->infoWin.win.y = WIN_Y_TGT;
    p_cur_ui->infoWin.win.y_tgt = p_cur_ui->infoWin.win.u;
    OLED_WinBlurAnimInit();
}

void OLED_InfoWinShow(Option *win, uint16_t time) {
    OLED_WinBlurAnim(time);

    OLED_Animation(&p_cur_ui->infoWin.win.y, &p_cur_ui->infoWin.win.y_tgt, p_cur_ui->upara->ani_param[WIN_ANI], time);

    OLED_SetPointColor(0);
    OLED_WinDrawRBox(&w_all, p_cur_ui->infoWin.win.l, (int16_t)p_cur_ui->infoWin.win.y,
                     INFO_WIN_W, INFO_WIN_H, INFO_WIN_R); // 弹窗背景黑边
    OLED_SetPointColor(1);
    OLED_WinDrawStr(&w_all, OLED_MIDDLE_H - OLED_GetStrWidth((char *)&(win->text[2]), WIN_FONT) / 2,
                    (int16_t)p_cur_ui->infoWin.win.y + 2, WIN_FONT, (uint8_t *)&(win->text[2])); // 提示文本跳过“! ”

    if (win->content != NULL) // 信息弹窗正文
        OLED_WinDrawStr(&w_all, p_cur_ui->infoWin.win.l + 5, p_cur_ui->infoWin.win.y + 17,
                        INFO_WIN_FONT, (uint8_t *)win->content);

    // indicator
    p_cur_ui->indicator.x_tgt = p_cur_ui->infoWin.win.l;
    p_cur_ui->indicator.y_tgt = (int16_t)p_cur_ui->infoWin.win.y;
    p_cur_ui->indicator.w_tgt = INFO_WIN_W;
    p_cur_ui->indicator.h_tgt = INFO_WIN_H;
}

void OLED_InfoWinReact(PageAddr bg, Option *select_win, uint16_t time) {
    if (p_cur_ui->infoWin.win.y == p_cur_ui->infoWin.win.y_tgt && p_cur_ui->infoWin.win.y != WIN_Y_TGT) // 弹窗进场动画结束时
    {
        InputMsg msg = OLED_MsgQueRead();
        switch (msg) {
        case msg_click: // 点击确认也会退出弹窗，不过，点击确认是会触发一次回调，点击返回则不会
        case msg_return:
            p_cur_ui->infoWin.win.y_tgt = WIN_Y_TGT; // 弹窗退场
            p_cur_ui->infoWin.win.state = 0;         // 状态标志，退出弹窗
            break;
        case msg_home:
            break;
        default:
            break;
        }
        if (msg != msg_none && msg != msg_return) // 只有弹窗内有动作，就会实时触发回调
        {
            Page *p = (Page *)bg;
            if (p->cb != NULL)
                p->cb(p, select_win);
        }
    }
}

//------------确认弹窗相关函数
#if UI_CONWIN_ENABLE

void OLED_ConWinAnimInit(PageAddr bg, uint16_t time) {
    UNUSED_PARAMETER(bg);
    p_cur_ui->confWin.win.y = CON_WIN_Y_TGT;
    p_cur_ui->confWin.win.y_tgt = p_cur_ui->confWin.win.u;
    OLED_WinBlurAnimInit();
}

void OLED_ConWinShow(Option *win, uint16_t time) {
    OLED_WinBlurAnim(time);

    OLED_Animation(&p_cur_ui->confWin.win.y, &p_cur_ui->confWin.win.y_tgt, p_cur_ui->upara->ani_param[WIN_ANI], time);

    OLED_SetPointColor(0);                                                                                                // 绘制外围黑框
    OLED_WinDrawRBox(&w_all, p_cur_ui->confWin.win.l, (int16_t)p_cur_ui->confWin.win.y, CON_WIN_W, CON_WIN_H, CON_WIN_R); // 弹窗背景黑边
    OLED_SetPointColor(1);
    // 绘制外框
    OLED_WinDrawRBoxEmpty(&w_all, p_cur_ui->confWin.win.l, (int16_t)p_cur_ui->confWin.win.y, CON_WIN_W, CON_WIN_H, CON_WIN_R);
    OLED_WinDrawStr(&w_all, OLED_MIDDLE_H - OLED_GetStrWidth((char *)&(win->text[2]), WIN_FONT) / 2,
                    (int16_t)p_cur_ui->confWin.win.y + 2, WIN_FONT, (uint8_t *)&(win->text[2])); // 提示文本跳过“# ”

    if (win->content != NULL) // 信息提示正文
        OLED_WinDrawStr(&w_all, p_cur_ui->confWin.win.l + 5, p_cur_ui->confWin.win.y + 17,
                        CON_WIN_FONT, (uint8_t *)win->content);

    OLED_WinDrawStr(&w_all, p_cur_ui->confWin.win.l + 15,
                    (int16_t)p_cur_ui->confWin.win.y + CON_WIN_H - CON_WIN_FONT.Height - 4, CON_WIN_FONT, (uint8_t *)"Yes");
    OLED_WinDrawStr(&w_all, p_cur_ui->confWin.win.r - 15 - CON_WIN_FONT.Width * 2,
                    (int16_t)p_cur_ui->confWin.win.y + CON_WIN_H - CON_WIN_FONT.Height - 4, CON_WIN_FONT, (uint8_t *)"No");

    // indicator
    p_cur_ui->indicator.h_tgt = CON_WIN_BTN_H;
    p_cur_ui->indicator.y_tgt = (int16_t)p_cur_ui->confWin.win.d - CON_WIN_FONT.Height - 6;
    if (win->val == true) {
        p_cur_ui->indicator.x_tgt = p_cur_ui->confWin.win.l + 15 - CON_WIN_FONT.Width;
        p_cur_ui->indicator.w_tgt = CON_WIN_FONT.Width * 5;
    } else {
        p_cur_ui->indicator.x_tgt = p_cur_ui->confWin.win.r - 15 - CON_WIN_FONT.Width * 3;
        p_cur_ui->indicator.w_tgt = CON_WIN_FONT.Width * 4;
    }
}

void OLED_ConWinReact(PageAddr bg, Option *win, uint16_t time) {
    if (p_cur_ui->confWin.win.y == p_cur_ui->confWin.win.y_tgt && p_cur_ui->confWin.win.y != CON_WIN_Y_TGT) // 弹窗进场动画结束
    {
        InputMsg msg = OLED_MsgQueRead();
        Page *p = (Page *)bg;
        ListPage *lp = (ListPage *)p_cur_ui->current_page;
        switch (msg) {
        case msg_add:
        case msg_sub:
            break;
        case msg_up:
        case msg_down: // 上下键在确认弹窗时用于切换
            win->val = !(win->val);
            break;
        case msg_click: // 对于确认弹窗来说，只有按下确认键，才会触发回调
            if ((p->cb) != NULL)
                p->cb(p, win);
            // 这儿不用break;因为确认结束，直接退出弹窗
            if (OLED_CheckPageType(p_cur_ui->current_page) == type_list && lp->page_setting == Setting_radio && win->val)
                p_cur_ui->lp_var.radio_click_flag = true; // 标记为1，用于OLED_RadioReact进行轮询判断单选
        case msg_return:
            p_cur_ui->confWin.win.y_tgt = CON_WIN_Y_TGT; // 弹窗退场
            p_cur_ui->confWin.win.state = 0;             // 标志退出弹窗状态
            break;
        case msg_home:
            return;
        default:
            break;
        }
    }
}

#endif
