#include "WouoUI_port.h"

extern void simulateSendBuff(uint8_t buff[8][128]);

void WouoUI_port_SendBuff(uint8_t buff[8][128]) {
    simulateSendBuff(buff);
}
