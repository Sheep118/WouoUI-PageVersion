#include "WouoUI/WouoUI.h"
#include "WouoUI/WouoUI_user.h"
#include "stdint.h"
#include <conio.h>
#include <graphics.h>
#include <time.h>

#define FORE_COLOR LIGHTBLUE // 前景颜色
#define BACK_COLOR WHITE     // 背景颜色

#define pixelSeize 3

uint16_t fps = 0;

void simulateSendBuff(uint8_t buff[OLED_HEIGHT / 8][OLED_WIDTH]) {
    BeginBatchDraw();
    cleardevice();
    for (uint8_t i = 0; i < OLED_HEIGHT / 8; i++)
        for (uint8_t j = 0; j < OLED_WIDTH; j++)
            for (uint8_t n = 0; n < 8; n++) {
                if (buff[i][j] & 0x01 << n) {
                    uint16_t x = j * pixelSeize, y = (i * 8 + n) * pixelSeize;
                    fillrectangle(x, y, x + pixelSeize - 1, y + pixelSeize - 1);
                }
            }
    EndBatchDraw();
    fps++;
}

void TimerEvent1() {
    OLED_UIProc(20);
}

void TimerEvent2() {
    OLED_RefreshBuff();
}

void TimerEvent3() {
    if (GetAsyncKeyState(VK_ESCAPE))
        OLED_MsgQueSend(msg_return);

    if (GetAsyncKeyState(VK_F1)) {
        OLED_MsgQueSend(msg_up);
        OLED_MsgQueSend(msg_sub);
    }

    if (GetAsyncKeyState(VK_F2))
        OLED_MsgQueSend(msg_click);

    if (GetAsyncKeyState(VK_F3)) {
        OLED_MsgQueSend(msg_down);
        OLED_MsgQueSend(msg_add);
    }

    if (GetAsyncKeyState(VK_F4))
        OLED_MsgQueSend(msg_sub);

    if (GetAsyncKeyState(VK_F5)) {
        OLED_MsgQueSend(msg_add);
    }
}

void TimerEvent4() {
    printf("fps:%d\n", fps);
    fps = 0;
}

int main() {
    // easyz
    // window
    initgraph(OLED_WIDTH * pixelSeize, OLED_HEIGHT * pixelSeize, NOCLOSE);
    HWND hwnd = GetHWnd();
    SetWindowPos(hwnd, NULL, 650, 120, OLED_WIDTH * pixelSeize, OLED_HEIGHT * pixelSeize, SWP_NOSIZE | SWP_NOZORDER);
    SetWindowText(hwnd, (char *)"WouoUI Simulate");
    // set color
    setcolor(FORE_COLOR);
    setfillcolor(FORE_COLOR);
    setbkcolor(BACK_COLOR);
    cleardevice();
    // timer
    SetTimer(hwnd, 1, 20, (TIMERPROC)TimerEvent1);
    SetTimer(hwnd, 2, 25, (TIMERPROC)TimerEvent2);
    SetTimer(hwnd, 3, 200, (TIMERPROC)TimerEvent3);
    // SetTimer(hwnd, 4, 1000, (TIMERPROC)TimerEvent4);

    // WouoUI
    TestUI_Init();

    while (1) {
    }

    closegraph();
    return 0;
}
